### Directory descriptions.
### CAUTION: These are not checked by CRAN.

- ./roc/
  work flows for ROC model.

- ./param/
  contains a set of minimum input parameters especially for simulations.
